import 'package:flutter/material.dart';
import 'package:travel_your_way/constants/loginConstrants.dart';
import 'package:travel_your_way/auth/loginScreen.dart';
int showPassword = 0;
String passwordIconUrl="assets/images/passwordIcon.png";
OutlineInputBorder textFieldsBorder=new OutlineInputBorder(

  borderSide:BorderSide(color: Colors.blue,width: 1.0),
  borderRadius:BorderRadius.all(Radius.circular(5.0)),
);
