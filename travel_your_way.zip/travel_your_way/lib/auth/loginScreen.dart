import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:travel_your_way/auth/signInWithGoogle.dart';
import 'package:travel_your_way/classes/routes.dart';
import 'package:travel_your_way/constants/loginConstrants.dart';
import 'package:travel_your_way/screens/homeScreen.dart';

class LoginScreen extends StatefulWidget {

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>  with TickerProviderStateMixin{
  AnimationController controller;
  Animation animation;
  FirebaseAuth _auth=FirebaseAuth.instance;
  int showPassword = 0;
  String _userEmail;
  bool _success=true;
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    // TODO: implement initState
    controller= AnimationController(
      duration: Duration(seconds: 1),
      vsync:this,);
    animation=CurvedAnimation(parent:controller,curve: Curves.decelerate);
     controller.forward();
     controller.addListener(() {
       setState(() {

       });
     });
    super.initState();
  }
  @override
  Widget build(BuildContext context) {

    var height=MediaQuery.of(context).size.height;
      return Container(
          height: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/images/loginBackground.png"),
                fit: BoxFit.cover,
              )),
        child: Scaffold(
                          backgroundColor: Colors.transparent,

            body:Container(
              margin: EdgeInsets.only(top: 40.0),
              padding: EdgeInsets.all(20.0),
              child: Form(
             key: _formKey,
                child: Column(
                  children: [
                    Container(
                    height:animation.value*100,
                  child: Image.asset("assets/images/logo.png",alignment: Alignment.center)),
                    SizedBox(height: 30.0,),
                    Expanded(
                      child: ListView(
                        children: [
                          Material(

                          elevation: 8.0,
                          borderRadius: BorderRadius.all(Radius.circular(12.0)),

                          child: Column(
                            children: [
                              Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 20.0),
                                  child:
                                  Text(
                                    "Login",
                                    style: TextStyle(
                                      color: Colors.blue,
                                      fontSize: 22.0,
                                    ),
                                  ),



                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 8.0),
                                child: Text(
                                  _success==true?"":" the email or password is incorrect",
                                  style: TextStyle(
                                    color: Colors.red,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 8.0),
                                child: TextFormField(
                                  controller: _emailController,
                                  obscureText: false,
                                  keyboardType: TextInputType.emailAddress,
                                  decoration: InputDecoration(
                                      focusedBorder: textFieldsBorder,
                                      disabledBorder: textFieldsBorder,

                                      contentPadding: EdgeInsets.all(4.0),
                                      border: textFieldsBorder,
                                      labelText: 'Email',
                                      hintText: "Email"),
                                  validator: (String value) {
                                    if (value.isEmpty || !value.contains('@')) {
                                      return 'email incorrect';
                                    }
                                    return null;
                                  },

                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 8.0),
                                child: TextFormField(
                                  controller: _passwordController,
                                  obscureText: showPassword == 0 ? true : false,
                                  onTap: () {
                                    setState(() {
                                      // listViewController.jumpTo(120.0);
                                    });
                                  },
                                  decoration: InputDecoration(
                                    suffixIcon: GestureDetector(
                                      child: Image.asset(passwordIconUrl,width: 20,height: 20,),
                                      onTap: () {
                                        setState(() {
                                          showPassword == 1
                                              ? showPassword = 0
                                              : showPassword = 1;
                                          passwordIconUrl.endsWith("assets/images/passwordIcon.png")?
                                          passwordIconUrl="assets/images/passwordIcon2.png":
                                          passwordIconUrl="assets/images/passwordIcon.png";
                                        });
                                      },
                                    ),
                                    focusedBorder: textFieldsBorder,
                                    disabledBorder: textFieldsBorder,
                                    contentPadding: EdgeInsets.all(4.0),
                                    border: textFieldsBorder,
                                    labelText: 'password',
                                    hintText: "Password",

                                  ),
                                  validator: (String value) {
                                    if (value.length<6) {
                                      return 'incorrect password';
                                    }
                                    return null;
                                  },
                                ),
                              ),

                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 12.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                        "don't have account?"
                                    ),
                                    GestureDetector(
                                      onTap: (){
                                        setState(() {
                                           navigateToSignUpScreen(context);
                                        });
                                      },
                                      child: Text(
                                        "Create Account",
                                        style: TextStyle(
                                          fontSize: 16.0,
                                          color: Colors.blue,
                                        ),
                                      ),
                                    )
                                  ],

                                ),


                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 12.0),
                                child: Material(
                                  elevation: 6.0,
                                  color: Colors.blue,
                                  borderRadius: BorderRadius.all(Radius.circular(8.0)),
                                  child: Container(
                                    height: 30.0,
                                    width: 90.0,
                                    child: FlatButton(

                                      onPressed: () {
                                       setState(() {
                                         if(_formKey.currentState.validate()){
                                           _signInWithEmailAndPassword();
                                         }
                                       });
                                      },
                                      child: Text("GO",style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w500
                                      ),),
                                    ),
                                  ),
                                ),
                              ),
                              Container(

                                margin: EdgeInsets.only(top: 15.0),
                                width: height>=340?MediaQuery.of(context).size.width - 140:MediaQuery.of(context).size.width-60,
                                alignment: Alignment.center,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        GestureDetector(

                                          child: Text(
                                            "Login With Phone",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              fontSize: 15.0,
                                              color: Colors.blueAccent,
                                            ),
                                          ),
                                          onTap: (){
                                            setState(() {
                                              navigateToLoginWithPhone(context);
                                            });

                                          },

                                        ),
                                        SizedBox(
                                          height: 14.0,
                                        ),
                                        GestureDetector(
                                          onTap: (){
                                            SignInWithGoogle().loginByGoogle();
                                            return HomeScreen();
                                          },
                                          child: Text(
                                            "login With Google",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              fontSize: 15.0,
                                              color: Colors.blueAccent,
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          height: 14.0,
                                        ),

                                      ],
                                    ),
                                    height>=325?SizedBox(width: 20.0,):SizedBox(width: 4.0,),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        Image.asset(
                                          "assets/images/phone.png",
                                          fit: BoxFit.cover,
                                          width: 18.0,
                                          height: 20.0,
                                          // alignment: Alignment.centerRight,
                                        ),
                                        SizedBox(
                                          height: 14.0,
                                        ),
                                        Image.asset(
                                          "assets/images/googleicon.png",
                                          fit: BoxFit.cover,
                                          width: 18.0,
                                          height: 20.0,
                                          // alignment: Alignment.centerRight,
                                        ),
                                        SizedBox(
                                          height: 14.0,
                                        ),

                                      ],
                                    )
                                  ],
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 15.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                        "Forgot Password?",
                                        style: TextStyle(
                                          fontSize: 16.0,
                                          color: Colors.blue,
                                        )
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                   ] ),
                    )
                  ],
                ),
              ),
            )
         ),
        );



  }
  void _signInWithEmailAndPassword() async {
    final user = (await _auth.signInWithEmailAndPassword(
      email: _emailController.text,
      password: _passwordController.text,
    )).user;

    if (user != null) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => HomeScreen()));
      setState(() {
        _success = true;
        _userEmail = user.email;
      });
    } else {
      setState(() {
        _success = false;
      });
    }
  }
}
