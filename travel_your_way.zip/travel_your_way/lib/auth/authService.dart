

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:travel_your_way/auth/signInWithGoogle.dart';
import 'package:travel_your_way/classes/routes.dart';
import 'package:travel_your_way/screens/homeScreen.dart';

class AuthService{
 bool emailSent;
  handleAuth(){
    return StreamBuilder(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (BuildContext context,snapShot){
     if(SignInWithGoogle().isSignIn){
       progressBar();
     }
     if(snapShot.hasData){
           return HomeScreen();

        }

       navigateToLoginInScreen(context);

      },
    );
  }
  signIn (AuthCredential credential) async{
    await FirebaseAuth.instance.signInWithCredential(credential);

  }
  Widget progressBar(){
    return Center(
      child: CircularProgressIndicator(),
    );
  }

  signOut() async{
   await FirebaseAuth.instance.signOut();
  }
   resetPassword( String email) async{
    await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
    emailSent=true;

  }
}