import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:travel_your_way/auth/loginScreen.dart';
import 'package:travel_your_way/auth/signupScreen.dart';
import 'package:travel_your_way/screens/loginWithPhone.dart';



void navigateToSignUpScreen(BuildContext context){
  Navigator.push(context, MaterialPageRoute(builder: (context) => SignUpScreen()));
}
void navigateToLoginInScreen(BuildContext context){
  Navigator.push(context, MaterialPageRoute(builder: (context) => LoginScreen()));
}
void navigateToLoginWithPhone(BuildContext context) {
  Navigator.push(
      context, MaterialPageRoute(builder: (context) => LoginWithPhone()));
}