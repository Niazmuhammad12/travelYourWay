import 'dart:async';


import 'package:flutter/material.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:data_connection_checker/data_connection_checker.dart';
import 'package:travel_your_way/auth/authService.dart';


class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  StreamSubscription<DataConnectionStatus> listener;

  bool InternetStatus = false;
  var contentmessage = "Unknown";
@override
  void initState() {
    // TODO: implement initState
  checkConnection(context);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/images/bg.png",), fit: BoxFit.cover,
          )
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: AnimatedSplashScreen(
          splash: Image.asset("assets/images/logo.png",
            fit: BoxFit.cover,
          ),
         nextScreen: InternetStatus?AuthService().handleAuth():Container(
           height: MediaQuery.of(context).size.height,
           color: Colors.white,
           child: Center(
             child: Column(
               mainAxisAlignment: MainAxisAlignment.center,
               crossAxisAlignment: CrossAxisAlignment.center,
               children:[ Text(
                 "No Internet",style: TextStyle(
                 fontSize: 20.0,
                 color: Colors.red
               ),
               ),
                 SizedBox(height: 10.0,),
                 RaisedButton(
                   onPressed: (){
                     setState(() {
                      checkConnection(context);

                     });

                   },
                   child: Text(
                     "Retry",style: TextStyle(
                       fontSize: 16.0,

                   ),
                   ),
                 ),
           ]
             ),
           ),
         ),
          splashTransition: SplashTransition.fadeTransition,
          duration: 60,
          splashIconSize: MediaQuery.of(context).size.width-60,


        ),
      ),


    );
  }

  void _showDialog(String title,String content ,BuildContext context) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              title: new Text(title),
              content: new Text(content),
              actions: <Widget>[
                new FlatButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      setState(() {
                        checkConnection(context);
                      });

                    },
                    child: new Text("Close"))
              ]
          );
        }
    );
  }

  checkConnection(BuildContext context) async{
    listener = DataConnectionChecker().onStatusChange.listen((status) {
      switch (status){
        case DataConnectionStatus.connected:
          setState(() {
            InternetStatus=true;
          });
          break;
        case DataConnectionStatus.disconnected:
           setState(() {
             InternetStatus=false;
           });
          contentmessage = "Please check your internet connection and try again";
          _showDialog("you are not connected to the internet",contentmessage,context);
          break;
      }
    });
    return await DataConnectionChecker().connectionStatus;
  }
}