import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:travel_your_way/auth/loginScreen.dart';
import 'package:travel_your_way/screens/splashScreen.dart';


import 'auth/initScreen.dart';


void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        home:SplashScreen()) ,
      );

}
