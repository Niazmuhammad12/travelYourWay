package com.example.travel_your_way

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
